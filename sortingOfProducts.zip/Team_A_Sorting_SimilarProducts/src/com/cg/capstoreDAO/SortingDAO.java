package com.cg.capstoreDAO;

import java.util.List;

import com.cg.capstoreDTO.Product;

public interface SortingDAO {

	 public List<Product> SortByRange(int price1, int price2); 
	 public List<Product>SortByAscendingOrder(); 
	 public List<Product> SortByDescendingOrder(); 
}
