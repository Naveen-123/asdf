package com.cg.capstoreDAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstoreDTO.Product;


@Repository
public class SortingDAOImpl implements SortingDAO{
	
/*@PersistenceContext
	private EntityManager entityManager;*/
	private JdbcTemplate template;
	
	



	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}



	@Transactional
	@Override
	public List<Product> SortByRange(int price1, int price2) {

			String sql="select * from product where price between '"+price1+"' and '"+price2+"'";
			
			 return template.query(sql,new RowMapper<Product>(){

				@Override
				public Product mapRow(ResultSet rs, int row)
						throws SQLException {
					Product product=new Product();
					product.setProductName(rs.getString(1));
					product.setPrice(rs.getInt(2));
					product.setProductDescription(rs.getString(3));
					
					return product;
				} 
			});
	}
		
			
			
			//return template.update(sql);
			/*finally {
		entityManager.close();
		}*/

	

	@Override
	public List<Product> SortByAscendingOrder() {
		String sql="select * from  product order by price asc";
				//return query.getResultList();
		 return template.query(sql,new RowMapper<Product>(){

				@Override
				public Product mapRow(ResultSet rs, int row)
						throws SQLException {
					Product product=new Product();
					product.setProductName(rs.getString(1));
					product.setPrice(rs.getInt(2));
					product.setProductDescription(rs.getString(3));
					
					return product;
				} 
			});
	}
	@Override
	public List<Product> SortByDescendingOrder() {
		String sql=
				"select * from  product order by price desc";
				//return query.getResultList();
		 return template.query(sql,new RowMapper<Product>(){

				@Override
				public Product mapRow(ResultSet rs, int row)
						throws SQLException {
					Product product=new Product();
					product.setProductName(rs.getString(1));
					product.setPrice(rs.getInt(2));
					product.setProductDescription(rs.getString(3));
					
					return product;
				} 
			});
	}
	}


