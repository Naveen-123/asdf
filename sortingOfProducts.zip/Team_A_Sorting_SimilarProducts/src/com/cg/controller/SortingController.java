package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;






import com.cg.capstoreDAO.SortingDAO;
import com.cg.capstoreDAO.SortingDAOImpl;
import com.cg.capstoreDTO.Product;


@Controller



public class SortingController {
	
	
	
		@Autowired
		
		private SortingDAO sortingDAO;
		
		@RequestMapping("/sortingByRangeOfPrice")
		
		
		String viewAllProducts( @RequestParam("price1") int price1, @RequestParam("price2")int price2, @ModelAttribute ("sort") SortingDAOImpl sdao,ModelMap map){
			List<Product> Product = sortingDAO.SortByRange(price1,price2);
			
		map.addAttribute("productList",Product);
		
			System.out.println(Product);
			return "productList";			
			
		}
		
		@RequestMapping(value="/sortingByAscendingPrice")
		
		
		String viewAllProducts1(ModelMap map2){
			
			
			System.out.println("out/................................................");
			List<Product> ProductASC = sortingDAO.SortByAscendingOrder();
			map2.addAttribute("productList",ProductASC);
			return "productList";
			
		}
		
		
		
		
		@RequestMapping("/sortingByDescendingPrice")
		String viewAllProducts2(ModelMap map3){
			List<Product> ProductDESC = sortingDAO.SortByDescendingOrder();
			map3.addAttribute("productList",ProductDESC);
			return "productList";
			
		}
		
		
	}

