
package com.cg.capstoreDTO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;



@Entity
public class Product 
{
    @Id
    @GeneratedValue
    private int productId;
    
    @Column(nullable = false)
    private String productName;
    
    @Column(nullable = false)
    private String productDescription;
    
    @Column(nullable = false)
    private String Category;
    
    @Column(nullable = false)
    private String image;
    
    @Column(nullable = false)
    private int price;
    
    @Column(nullable = false)
    private String brand;
    
    @Column(nullable = false)
    private int quantity;
    
    
    private int discount;
    
    
    private Date expiryDate;
    
 
    
    
    
	public int getProductId() {
		return productId;
	}


	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	
    
    
    
    
    
    
}
