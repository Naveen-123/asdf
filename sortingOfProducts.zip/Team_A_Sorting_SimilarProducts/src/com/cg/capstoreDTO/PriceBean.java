package com.cg.capstoreDTO;

public class PriceBean {

	
	private int price1;
	private int price2;
	
	
	public int getPrice1() {
		return price1;
	}
	public void setPrice1(int price1) {
		this.price1 = price1;
	}
	
	
	public int getPrice2() {
		return price2;
	}
	public void setPrice2(int price2) {
		this.price2 = price2;
	}
}
