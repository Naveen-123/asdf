package test.CG;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import pojo.Actor;
import pojo.Album;
import pojo.Category;
import pojo.Film;
import repository.FilmRepository;
import service.FilmService;

public class FilmServiceTestCases {

	private FilmService service;

	@Mock
	private FilmRepository repo;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		service = new FilmService(repo);
	}

	@Test
	public void isValidDataFilm() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<pojo.Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("action");
		film.setLanguage("kannada");
		film.setLength((short) 120);
		film.setRating((byte) 5);
		film.setReleaseYear((short) 2015);
		film.setTitle("kotigobba");

		Mockito.when(repo.save(film)).thenReturn(true);

		assertEquals("successfull", service.addFilm(film));
	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemError() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<pojo.Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("action");
		film.setLanguage("kannada");
		film.setLength((short) 120);
		film.setRating((byte) 5);
		film.setReleaseYear((short) 2015);
		film.setTitle("kotigobba");

		Mockito.when(repo.save(film)).thenThrow(new SQLException());

		service.addFilm(film);
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void isInvalidDataFilm() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<pojo.Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("action");
		film.setLanguage("kannada");
		film.setLength((short) 120);
		film.setRating((byte) 8);
		film.setReleaseYear((short) 2015);
		film.setTitle("kotigobba");

		Mockito.when(repo.save(film)).thenReturn(false);

		service.addFilm(film);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void isNullDataFilm() {
		Film film = null;

		Mockito.when(repo.save(film)).thenReturn(false);

		service.addFilm(film);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNull() {
		Film f = null;
		/*
		 * Mockito.when(repo.modifyFilm(f)).thenReturn(false);
		 * assertEquals("fail", service.modifyFilm(f));
		 */
		service.modifyFilm(f);
	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInModifyFilm() {
		Film f = new Film(2);
		Mockito.when(repo.modifyFilm(f)).thenThrow(new SQLException());
		service.modifyFilm(f);
	}

	@Test
	public void dataIsNotPresent() {
		Film f = new Film(2);
		Mockito.when(repo.modifyFilm(f)).thenReturn(false);
		assertEquals("failed", service.modifyFilm(f));
	}

	@Test
	public void ifDataIsPresent() {
		Film f = new Film(1);
		Mockito.when(repo.deleteFilm(f)).thenReturn(true);
		assertEquals("succesfull", service.deleteFilm(f));

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNullDelele() {
		Film f = null;
		Mockito.when(repo.deleteFilm(f)).thenReturn(false);
		service.deleteFilm(f);
	}

	@Test
	public void dataIsNotPresentDelele() {
		Film f = new Film(2);
		Mockito.when(repo.deleteFilm(f)).thenReturn(false);
		assertEquals("failed", service.modifyFilm(f));
	}

	@Test
	public void ifDataIsPresentDelele() {
		Film f = new Film(1);
		Mockito.when(repo.deleteFilm(f)).thenReturn(true);
		assertEquals("succesfull", service.deleteFilm(f));

	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInDeleteFilm() {
		Film f = new Film(2);
		Mockito.when(repo.deleteFilm(f)).thenThrow(new SQLException());
		service.deleteFilm(f);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByTitleInputNull() {
		service.searchFilmByTitle(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByTilteInputNotPresent() {

		Mockito.when(repo.searchFilmByTitle("abc")).thenReturn(null);
		service.searchFilmByTitle("abc");

	}

	@Test
	public void findByTitleIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(repo.searchFilmByTitle("Sultan")).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));
		assertFalse(service.searchFilmByTitle("Sultan").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByTitleIfSystemError() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(repo.searchFilmByTitle("Sultan")).thenThrow(new SQLException());
		service.searchFilmByTitle("Sultan");

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByCategoryInputNull() {
		service.searchFilmByCategory(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByCategoryInputNotPresent() {

		Mockito.when(repo.searchFilmByCategory("abc")).thenReturn(null);
		service.searchFilmByCategory("abc");

	}

	@Test
	public void findByCategoryIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(repo.searchFilmByCategory("Sultan")).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));
		assertFalse(service.searchFilmByCategory("Sultan").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByCategoryIfSystemError() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(repo.searchFilmByCategory("Sultan")).thenThrow(new SQLException());
		service.searchFilmByCategory("Sultan");

	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void findByRatingInputNull() {
		service.searchFilmByRating((short) 0);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByRatingInputNotPresent() {

		Mockito.when(repo.searchFilmByRating((short) 3)).thenReturn(null);
		service.searchFilmByRating((short) 3);

	}

	@Test
	public void findByRatingIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(repo.searchFilmByRating((short) 3)).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));
		assertFalse(service.searchFilmByRating((short) 3).isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByRatingIfSystemError() {

		Mockito.when(repo.searchFilmByRating((short) 3)).thenThrow(new SQLException());
		service.searchFilmByRating((short) 3);

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByLanguageInputNull() {
		service.searchFilmByLanguage(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByLanguageInputNotPresent() {

		Mockito.when(repo.searchFilmByLanguage("abc")).thenReturn(null);
		service.searchFilmByLanguage("abc");

	}

	@Test
	public void findByLanguageIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(repo.searchFilmByLanguage("Sultan")).thenReturn(l);
		
		assertFalse(service.searchFilmByLanguage("Sultan").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByLanguageIfSystemError() {

		Mockito.when(repo.searchFilmByLanguage("abc")).thenThrow(new SQLException());
		service.searchFilmByLanguage("abc");

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByActorInputNull() {
		service.searchFilmByActor(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByActorInputNotPresent() {

		Mockito.when(repo.searchFilmByActor(null)).thenReturn(null);
		service.searchFilmByActor(null);

	}

	@Test
	public void findByActorIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Actor a = new Actor();
		Mockito.when(repo.searchFilmByActor(a)).thenReturn(l);

		assertFalse(service.searchFilmByActor(a).isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByActorIfSystemerror() {
		Actor a = new Actor();
		Mockito.when(repo.searchFilmByActor(a)).thenThrow(new SQLException());
		service.searchFilmByActor(a);

	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void findByRealeaseYearInputNull() {
		service.searchFilmByRating((short) 0);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByRealeaseYearInputNotPresent() {

		Mockito.when(repo.searchFilmByRating((short) 2003)).thenReturn(null);
		service.searchFilmByRating((short) 2003);

	}

	@Test
	public void findByRealeaseYearIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(repo.searchFilmByRealeaseYear((short) 2003)).thenReturn(l);
	
		assertFalse(service.searchFilmByRealeaseYear((short) 2003).isEmpty());

	}
	@Test(expected = java.lang.Exception.class)
	public void findByRealeaseYearIfSystemError() {

		Mockito.when(repo.searchFilmByRating((short) 2003)).thenThrow(new SQLException());
		service.searchFilmByRating((short) 2003);

	}

}
